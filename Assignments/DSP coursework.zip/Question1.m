clc, clear, close all;

clouds2 = imread('Clouds 2.jpg');

figure(1)
subplot(2,2,1)
imshow(clouds2);
title('Original Photo')

subplot(2,2,2)
imshow(clouds2(:,:,1));
title('Red Component')

subplot(2,2,3)
imshow(clouds2(:,:,2));
title('Green Component')

subplot(2,2,4)
imshow(clouds2(:,:,3));
title('Blue Component')

figure(2)
subplot(2,2,1)
imshow(clouds2);
title('Original Photo')

subplot(2,2,2)
imhist(clouds2(:,:,1));
title('Red Component Histogram')

subplot(2,2,3)
imhist(clouds2(:,:,2));
title('Green Component Histogram')

subplot(2,2,4)
imhist(clouds2(:,:,3));
title('Blue Component Histogram')

disp('Max value of red')
disp(max(imhist(clouds2(:,:,1))))

disp('Max value of green')
disp(max(imhist(clouds2(:,:,2))))

disp('Max value of blue')
disp(max(imhist(clouds2(:,:,3))))


