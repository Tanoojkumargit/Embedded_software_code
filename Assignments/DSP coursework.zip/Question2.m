clc, clear, close all;

clouds = imread('Clouds.jpg');
clouds2 = imread('Clouds 2.jpg');

grayscaleClouds = rgb2gray(clouds);
grayscaleClouds2 = rgb2gray(clouds2);

eqClouds = histeq(grayscaleClouds, 256);
eqClouds2 = histeq(grayscaleClouds2, 256);

figure(1)

subplot(2,2,1)
imshow(grayscaleClouds)
title('Original Image')

subplot(2,2,2)
imshow(eqClouds)
title('Equalized Image')

subplot(2,2,3)
imhist(grayscaleClouds)
title('Histogram of original image')

subplot(2,2,4)
imhist(eqClouds)
title('Histogram of equalized image')

figure(2)
subplot(2,2,1)
imshow(grayscaleClouds2)
title('Original Image')

subplot(2,2,2)
imshow(eqClouds2)
title('Equalized Image')

subplot(2,2,3)
imhist(grayscaleClouds2)
title('Histogram of original image')

subplot(2,2,4)
imhist(eqClouds2)
title('Histogram of equalized image')
