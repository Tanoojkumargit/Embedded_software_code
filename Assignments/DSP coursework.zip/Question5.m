clc, clear, close all;

moonlight = imread('Moonlight.jpg');

grayscaleMoonlight = rgb2gray(moonlight);

medianFiltered = medfilt2(grayscaleMoonlight, [3 3]);

gaussianFilter = fspecial('gaussian', [3 3], 0.5);

gaussianFiltered = imfilter(grayscaleMoonlight, gaussianFilter);

sobelOnOriginalImage = edge(grayscaleMoonlight, 'sobel', 0.06);
sobelOnMedianFilteredImage = edge(medianFiltered, 'sobel', 0.06);
sobelOnGaussianFilteredImage = edge(gaussianFiltered, 'sobel', 0.06);


figure
subplot(2,2,1)
imshow(grayscaleMoonlight)
title('Original Image')

subplot(2,2,2)
imshow(sobelOnOriginalImage)
title('Sobel edge detection on Original image')

subplot(2,2,3)
imshow(sobelOnGaussianFilteredImage)
title('Sobel edge detection on Gaussian Filtered image')

subplot(2,2,4)
imshow(sobelOnMedianFilteredImage)
title('Sobel edge detection on Median Filtered image')