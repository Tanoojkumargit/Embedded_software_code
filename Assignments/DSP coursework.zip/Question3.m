clc, clear, close all;

moonlight = imread('Moonlight.jpg');

grayscaleMoonlight = rgb2gray(moonlight);

threshold4 = edge(grayscaleMoonlight, 'sobel', 0.04);
threshold6 = edge(grayscaleMoonlight, 'sobel', 0.06);
threshold8 = edge(grayscaleMoonlight, 'sobel', 0.08);

figure
subplot(2,2,1)
imshow(grayscaleMoonlight)
title('Original Image')

subplot(2,2,2)
imshow(threshold4)
title('Edge Detection - with Threshold value 0.04')

subplot(2,2,3)
imshow(threshold6)
title('Edge Detection - with Threshold value 0.06')

subplot(2,2,4)
imshow(threshold8)
title('Edge Detection - with Threshold value 0.08')

