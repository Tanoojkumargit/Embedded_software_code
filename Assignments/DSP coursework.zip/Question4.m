clc, clear, close all;

moonlight = imread('Moonlight.jpg');

grayscaleMoonlight = rgb2gray(moonlight);


gaussianFilter = fspecial('gaussian', [3 3], 0.5);

gaussianFiltered = imfilter(grayscaleMoonlight, gaussianFilter);
medianFiltered = medfilt2(grayscaleMoonlight, [3 3]);

% figure
% imshow(grayscaleMoonlight)

figure(2)
subplot(2,2,1)
imshow(grayscaleMoonlight)
title('Original Image')

subplot(2,2,3)
imshow(gaussianFiltered)
title('3 x 3 Gaussian Filter')

subplot(2,2,4)
imshow(medianFiltered)
title('3 x 3 Median Filter')